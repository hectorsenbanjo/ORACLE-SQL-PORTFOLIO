# 📆 Date Formatting

This query shows how to use `TO_CHAR` to format Oracle dates for better readability.

**Example Format Output:**
- January 15, 2020
- December 01, 2019
