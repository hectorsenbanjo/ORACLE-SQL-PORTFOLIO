# 🧑‍💼 Recent Hires (Last 90 Days)

This query returns employees who were hired in the last 90 days using date subtraction on `SYSDATE`.

**Use Cases:**
- HR onboarding reports
- Recent recruitment analysis
